const core=require('./core.cjs');
function createService(adapter) {
 return async function handle(input,uid,client='local') {
  const {action}=input||{};
  if(action==='lookup'){
   await adapter.limit(client);return core.lookup(await adapter.read(),input.phone);
  }
  if(action==='get')return core.read(await adapter.read(),uid,input.path);
  if(action==='commit') {
   let result;
   await adapter.mutate(state=>{result=core.commit(state,uid,input.puts,input.dels);return result.state});
   return {ok:true};
  }
  if(action==='patch'){await adapter.mutate(s=>core.patch(s,uid,input.updates));return {ok:true};}
  if(action==='purgeDemo'){
   await adapter.mutate(original=>{
    core.role(original,uid,true);const state=structuredClone(original),phones=new Set();
    for(const rows of Object.values(state.bookings||{}))for(const [id,x] of Object.entries(rows))if(/^demo[-_]/.test(id)&&/^010000\d{5}$/.test(x.phone)){phones.add(x.phone);delete rows[id];}
    for(const p of phones){
     if(Object.values(state.bookings||{}).some(rows=>Object.values(rows).some(x=>x.phone===p)))continue;
     delete state.patients?.[p];delete state.files?.[p];delete state.complaints?.[p];
     for(const [id,n] of Object.entries(state.inbox||{}))if(n.p===p)delete state.inbox[id];
    }
    core.rebuild(state);return state;
   });return {ok:true};
  }
  if(action==='userCreate') {
   core.role(await adapter.read(),uid,true);
   if(!/^[a-z0-9._-]{3,64}$/.test(input.u||'')||typeof input.p!=='string'||input.p.length<6||input.p.length>128||!['dmn','alex','nurse'].includes(input.br))core.fail('بيانات الحساب غير صحيحة');
   const user=await adapter.createUser(input.u,input.p);
   try{await adapter.mutate(s=>core.patch(s,uid,{['roles/'+user]:input.br==='nurse'?{r:'nurse',u:input.u}:{r:'sec',u:input.u,br:input.br}}));}
   catch(e){await adapter.deleteUser(user);throw e;}
   return {uid:user};
  }
  core.fail('عملية غير مسموحة',403);
 };
}
module.exports={createService};
