const cases=require('./cases.cjs');
const BRANCHES = ['dmn','alex'];
const STATES = ['wait','exam','done','no','cx'];
const fail = (message, status=400) => { const e=new Error(message);e.status=status;throw e; };
function phone(p) {
 return String(p||'').replace(/[٠-٩۰-۹]/g,d=>{const n=d.charCodeAt(0);return n>=1776?n-1776:n-1632}).replace(/[\s()+-]/g,'').replace(/^(?:0020|20)(?=1)/,'0');
}
function today(now=new Date()) {
 const p=Object.fromEntries(new Intl.DateTimeFormat('en-CA',{timeZone:'Africa/Cairo',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(now).map(x=>[x.type,x.value]));
 return p.year+'-'+p.month+'-'+p.day;
}
function date(d) {
 const parsed=new Date(d+'T00:00:00Z');
 if(!/^\d{4}-\d{2}-\d{2}$/.test(d||'')||!Number.isFinite(parsed.getTime())||parsed.toISOString().slice(0,10)!==d)fail('اختر تاريخاً صحيحاً');
 return d;
}
function id(s) { if(typeof s!=='string'||! /^[A-Za-z0-9_-]{1,128}$/.test(s))fail('معرّف غير صحيح');return s; }
function role(state,uid,doctor=false) {
 const r=state.roles?.[uid];
 if(!r || !(r.r==='doctor'||r.r==='nurse'||(r.r==='sec'&&BRANCHES.includes(r.br))))fail('NOAUTH',403);
 if(doctor&&r.r!=='doctor')fail('غير مصرح بهذه العملية',403);
 return r;
}
function allowed(r,b) {if(r.r!=='doctor'&&r.br!==b)fail('غير مصرح بتعديل هذا الفرع',403);}
function booking(n) {
 if(!n||typeof n!=='object')fail('حجز غير صحيح');
 const p=phone(n.phone);
 if(!/^01[0125]\d{8}$/.test(p)||!BRANCHES.includes(n.b)||!['exam','cons'].includes(n.v)||!STATES.includes(n.s||'wait'))fail('بيانات الحجز غير صحيحة');
 const name=String(n.name||'').trim(),nt=String(n.nt||'').trim();
 if(!name||name.length>120||nt.length>2000)fail('راجع الاسم والملاحظات');
 return {id:id(n.id),name,phone:p,b:n.b,v:n.v,s:n.s||'wait',date:date(n.date),nt};
}
function rebuild(state) {
 state.track={};
 for(const [d,rows] of Object.entries(state.bookings||{})){
  const list=Object.values(rows||{});
  for(const b of BRANCHES) {
   const q=list.filter(x=>x.b===b).sort((a,z)=>a.no-z.no);
   let ahead=0;
   for(const x of q){
    state.track[d]||={};
    state.track[d][x.phone]={no:x.no,s:x.s,b:x.b,v:x.v,ahead};
    if(x.s==='wait'||x.s==='exam')ahead++;
   }
  }
 }
 return state;
}
function commit(state, uid, puts, dels, now=today()) {
 state=structuredClone(state||{}); const r=role(state,uid);
 if(!Array.isArray(puts)||!Array.isArray(dels)||puts.length+dels.length>100||!puts.length&&!dels.length)fail('دفعة غير صحيحة');
 state.bookings||={};state.sequences||={};
 const seen=new Set();
 for(const raw of [...dels,...puts.map(p=>p.n)]){if(seen.has(raw?.id))fail('معرّف مكرر');seen.add(raw?.id);}
 const remove = (old, deleteOnly) => {
  date(old.date);id(old.id);
  const live=state.bookings[old.date]?.[old.id];
  if(!live)fail('الحجز تغيّر أو حُذف. أعد التحميل.',409);
  allowed(r,live.b);
  if(deleteOnly&&r.r!=='doctor')fail('حذف الحجوزات متاح للدكتور فقط',403);
  if((live.rev||0)!==(old.rev||0))fail('الحجز عُدّل في جلسة أخرى. أعد التحميل.',409);
  delete state.bookings[old.date][old.id];return live;
 };
 dels.forEach(x=>remove(x,true));
 for(const p of puts){
  const n=booking(p.n);allowed(r,n.b);
  const old=p.o?remove(p.o,false):null;
  if(!old&&r.r!=='doctor'&&n.date<now)fail('لا يمكن الحجز في تاريخ سابق');
  if(old&&r.r!=='doctor'&&['name','phone','v','nt','date','b'].some(k=>n[k]!==old[k]))fail('تعديل بيانات الحجز متاح للدكتور فقط',403);
  for(const rows of Object.values(state.bookings))if(rows?.[n.id])fail('معرّف الحجز موجود بالفعل',409);
  const rows=state.bookings[n.date]||={};
  if(Object.values(rows).some(x=>phone(x.phone)===n.phone))fail('هذا الرقم لديه حجز بالفعل في هذا اليوم',409);
  const moved=!old||old.date!==n.date||old.b!==n.b;
  const seqKey=n.date+'_'+n.b;
  const max=Math.max(state.sequences[seqKey]||0,0,...Object.values(rows).filter(x=>x.b===n.b).map(x=>Number(x.no)||0));
  n.no=moved?max+1:old.no;
  state.sequences[seqKey]=Math.max(max,n.no);
  n.rev=(old?.rev||0)+1;
  rows[n.id]=n;
 }
 rebuild(state);cases.indexPatients(state);return {state};
}
function read(state,uid,path) {
 if(path==='settings')return state.settings||null;
 const r=role(state,uid);
 if(path==='roles/'+uid)return state.roles[uid];
 if(path==='roles'){role(state,uid,true);return state.roles||{};}
 if(/^(patients|complaints|files|inbox)(?:\/|$)/.test(path))return cases.read(state,r,path);
 if(r.r==='nurse')fail('غير مصرح',403);
 if(/^bookings(?:\/\d{4}-\d{2}-\d{2})?$/.test(path)){
  const d=path.split('/')[1];if(d)date(d);
  if(r.r==='doctor')return d?(state.bookings?.[d]||{}):(state.bookings||{});
  if(!d)fail('اختر يوماً لعرض الحجوزات',403);
  return Object.fromEntries(Object.entries(state.bookings?.[d]||{}).filter(([,x])=>x.b===r.br));
 }
 fail('مسار غير مسموح',403);
}
function schedule(s) {
 if(!s||!Array.isArray(s.d)||!s.d.length||!s.d.every(d=>Number.isInteger(d)&&d>=0&&d<=6)||!/^([01]\d|2[0-3]):[0-5]\d$/.test(s.f)||!/^([01]\d|2[0-3]):[0-5]\d$/.test(s.t)||s.f>=s.t)fail('مواعيد غير صحيحة');
 return {d:[...new Set(s.d)],f:s.f,t:s.t};
}
function patch(state,uid,updates) {
 state=structuredClone(state||{});const r=role(state,uid);
 if(updates&&Object.keys(updates).every(p=>/^(patients|complaints|files|inbox)\//.test(p)))return cases.patch(state,r,updates,module.exports);
 role(state,uid,true);
 if(!updates||Array.isArray(updates)||typeof updates!=='object'||Object.keys(updates).length>10)fail('تحديث غير صحيح');
 state.settings||={};state.roles||={};
 for(const [path,value] of Object.entries(updates)){
  if(path==='settings'||path==='settings/avg'){
   const avg=path==='settings'?value.avg:value;
   if(!Number.isInteger(avg)||avg<1||avg>180)fail('متوسط الكشف من 1 إلى 180 دقيقة');
   state.settings.avg=avg;
   if(path==='settings'&&value.sched){state.settings.sched||={};for(const b of BRANCHES)state.settings.sched[b]=schedule(value.sched[b]);}
  }else if(/^settings\/sched\/(dmn|alex)$/.test(path)){
   state.settings.sched||={};state.settings.sched[path.split('/')[2]]=schedule(value);
  }else if(/^roles\/[A-Za-z0-9_-]{1,128}(?:\/br)?$/.test(path)){
   const [,key,field]=path.split('/');if(key===uid||state.roles[key]?.r==='doctor')fail('لا يمكن تغيير صلاحية الدكتور',403);
   if(field){if(!state.roles[key]||!BRANCHES.includes(value))fail('فرع غير صحيح');state.roles[key].br=value;}
   else if(value===null)delete state.roles[key];
   else{if(!['sec','nurse'].includes(value.r)||(value.r==='sec'&&!BRANCHES.includes(value.br))||!/^[a-z0-9._-]{3,64}$/.test(value.u))fail('حساب غير صحيح');state.roles[key]={r:value.r,u:value.u,...(value.r==='sec'?{br:value.br}:{})};}
  }else fail('مسار كتابة غير مسموح',403);
 }
 return state;
}
function lookup(state,p,now=today()) {
 p=phone(p);if(!/^01[0125]\d{8}$/.test(p))return null;
 const x=Object.values(state.bookings?.[now]||{}).find(x=>x.phone===p);
 if(!x)return null;return state.track?.[now]?.[p]||null;
}
module.exports={phone,today,date,role,booking,commit,read,patch,lookup,rebuild,fail,schedule};
